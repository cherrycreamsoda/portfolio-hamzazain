import styles from "./page.module.css";

export default function Page() {
  return (
    <div className={styles.container}>
      {/* Header */}
      <header className={styles.header}>
        <div className={styles.logo}>Shape.</div>
        <nav className={styles.nav}>
          <a href="#" className={styles.navLink}>
            Services
            <span className={styles.badge}>13</span>
          </a>
          <a href="#" className={styles.navLink}>
            Work
          </a>
          <a href="#" className={styles.navLink}>
            About
          </a>
          <a href="#" className={styles.navLink}>
            Blog
          </a>
          <a href="#" className={styles.navLink}>
            Contact
          </a>
        </nav>
        <div className={styles.headerRight}>
          <button className={styles.themeToggle}>☀</button>
          <button className={styles.ctaButton}>
            Start a project
            <span className={styles.arrow}>→</span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className={styles.main}>
        <div className={styles.heroText}>
          <div className={styles.greeting}>
            <span className={styles.dot}>•</span>
            Hiya, we're Shape
            <span className={styles.wave}>👋</span>
          </div>
          <h1 className={styles.title}>
            A web design and
            <br />
            branding agency
            <br />
            in Manchester
          </h1>
          <div className={styles.buttons}>
            <button className={styles.viewWork}>
              View our work
              <span className={styles.arrow}>→</span>
            </button>
            <button className={styles.meetTeam}>
              Meet the team
              <span className={styles.arrow}>→</span>
            </button>
          </div>
        </div>

        {/* Floating Elements */}
        <div className={styles.floatingElements}>
          {/* Pineapple Card */}
          <div className={`${styles.pineappleCard} ${styles.clipSvg}`}>
            <div className={styles.cardContent}>
              <img
                src="/placeholder.svg?height=200&width=150"
                alt="Pineapple design"
                className={styles.pineappleImage}
              />
              <div className={styles.profileCircle}>
                <img
                  src="/placeholder.svg?height=60&width=60"
                  alt="Team member"
                />
              </div>
              <div className={styles.cardText}>
                <div className={styles.boldText}>SUP?</div>
                <div className={styles.boldText}>MY NAME</div>
                <div className={styles.boldText}>IS ASHLEY.</div>
              </div>
            </div>
          </div>

          {/* Duck Card */}
          <div className={`${styles.duckCard} ${styles.clipSvg}`}>
            <img
              src="/placeholder.svg?height=80&width=80"
              alt="Rubber duck"
              className={styles.duckImage}
            />
          </div>

          {/* Phone Mockup */}
          <div className={styles.phoneMockup}>
            <div className={styles.phoneScreen}>
              <img
                src="/placeholder.svg?height=120&width=60"
                alt="Pineapple app"
              />
            </div>
          </div>

          {/* Circular Badges */}
          <div className={styles.circularBadges}>
            <div className={styles.badge1}>
              <img src="/placeholder.svg?height=40&width=40" alt="Coffee" />
            </div>
            <div className={styles.badge2}>
              <img src="/placeholder.svg?height=40&width=40" alt="Coffee" />
            </div>
            <div className={styles.badge3}>
              <img src="/placeholder.svg?height=40&width=40" alt="Coffee" />
            </div>
          </div>

          {/* Color Stack */}
          <div className={styles.colorStack}>
            <div
              className={styles.colorBar}
              style={{ backgroundColor: "#ffffff" }}
            ></div>
            <div
              className={styles.colorBar}
              style={{ backgroundColor: "#00ffff" }}
            ></div>
            <div
              className={styles.colorBar}
              style={{ backgroundColor: "#ff69b4" }}
            ></div>
            <div
              className={styles.colorBar}
              style={{ backgroundColor: "#ffff00" }}
            ></div>
          </div>

          {/* Video Card */}
          <div className={styles.videoCard}>
            <img
              src="/placeholder.svg?height=120&width=200"
              alt="Pineapples video"
              className={styles.videoThumbnail}
            />
            <div className={styles.videoText}>
              PINEAPPLES,
              <br />
              WTF?
            </div>
          </div>

          {/* Profile Card */}
          <div className={`${styles.profileCard} ${styles.clipSvg}`}>
            <div className={styles.profileContent}>
              <img
                src="/placeholder.svg?height=50&width=50"
                alt="Andy"
                className={styles.profileImage}
              />
              <div className={styles.profileText}>
                <div className={styles.profileName}>Hear from Andy</div>
                <div className={styles.profileTitle}>Co-Founder of Shape</div>
              </div>
            </div>
          </div>

          {/* Yellow Rectangle */}
          <div className={styles.yellowRect}></div>

          {/* Business Cards */}
          <div className={styles.businessCards}>
            <div className={styles.businessCard}>
              <div className={styles.cardHeader}>STRESS HEADS</div>
              <div className={styles.cardSubtext}>
                CREATIVE STRESS SOLUTIONS
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* SVG Clip Paths */}
      <svg width="0" height="0" style={{ position: "absolute" }}>
        <defs>
          <clipPath id="notchClip" clipPathUnits="objectBoundingBox">
            <path
              d="
              M 0.35,0
              Q 0.25,0 0.25,0.1
              V 0.25
              Q 0.25,0.35 0.15,0.35
              H 0.1
              Q 0,0.35 0,0.45
              V 0.9
              Q 0,1 0.1,1
              H 0.9
              Q 1,1 1,0.9
              V 0.1
              Q 1,0 0.9,0
              Z
            "
            />
          </clipPath>
          <clipPath id="roundedClip" clipPathUnits="objectBoundingBox">
            <path
              d="
              M 0.1,0
              H 0.9
              Q 1,0 1,0.1
              V 0.9
              Q 1,1 0.9,1
              H 0.1
              Q 0,1 0,0.9
              V 0.1
              Q 0,0 0.1,0
              Z
            "
            />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}
