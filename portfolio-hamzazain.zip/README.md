# portfolio-hamzazain
A personal portfolio project by Hamza Zain (me), built with Next.js, a full-stack React framework that supports server-side rendering, static site generation, and API routes.
